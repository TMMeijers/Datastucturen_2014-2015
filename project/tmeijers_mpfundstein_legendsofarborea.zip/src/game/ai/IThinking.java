package game.ai;

import java.util.ArrayList;

public interface IThinking {
	void thinkingDone(ArrayList<AiMove> moves);
}